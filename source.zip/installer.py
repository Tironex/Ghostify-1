#!/usr/bin/env python3
"""Lädt eine fertige Ghostify-Version von GitHub herunter und installiert sie. Rust, Node und
Visual Studio werden nicht gebraucht: Gebaut wird im Workflow "Build Ghostify" deines Repositorys.

Benutzung:
    python installer.py                              neuestes Release von Tironex/Ghostify-1 installieren
    python installer.py --repo NAME/REPO             das neueste Release installieren
    python installer.py --repo NAME/REPO --silent    Windows: ohne Setup-Fenster installieren
    python installer.py --repo NAME/REPO --cli       zusätzlich das Kommandozeilen-Tool laden
    python installer.py --repo NAME/REPO --tag v0.1.0    ein bestimmtes Release
    python installer.py --repo NAME/REPO --token ghp_...  für ein privates Repository
                                                     (oder die Variable GITHUB_TOKEN setzen)
    python installer.py --repo NAME/REPO --no-install    nur herunterladen
    python installer.py --zip PFAD/zip-datei.zip     eine schon geladene ZIP-Datei installieren (ohne Internet)
    python installer.py --zip PFAD/Ghostify-setup.exe    oder direkt einen Installer starten

Die Dateien werden vor dem Start auf Größe und, wenn GitHub eine liefert, auf die SHA-256-Prüfsumme
kontrolliert. Windows zeigt eventuell eine SmartScreen-Warnung, weil der Installer nicht mit einem
bezahlten Zertifikat signiert ist.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import stat
import shutil
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

API = os.environ.get("GHOSTIFY_API", "https://api.github.com")
SYSTEM = platform.system()  # "Windows", "Linux" or "Darwin"
MACHINE = platform.machine().lower()
USER_AGENT = "ghostify-installer"
DEFAULT_REPO = "Tironex/Ghostify-1"
REPO_PATTERN = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


class InstallerError(Exception):
    """A step failed; the message says what to do."""


class _DropAuthOnRedirect(urllib.request.HTTPRedirectHandler):
    """GitHub redirects downloads to another host; the token must not follow."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and urllib.parse.urlparse(newurl).netloc != urllib.parse.urlparse(req.full_url).netloc:
            new.headers.pop("Authorization", None)
            new.unredirected_hdrs.pop("Authorization", None)
        return new


OPENER = urllib.request.build_opener(_DropAuthOnRedirect)


def say(message: str) -> None:
    print(f"\n==> {message}", flush=True)


def request(url: str, token: Optional[str], accept: str) -> urllib.request.Request:
    headers = {"User-Agent": USER_AGENT, "Accept": accept}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return urllib.request.Request(url, headers=headers)


def fetch_release(repo: str, tag: Optional[str], token: Optional[str]) -> Dict[str, Any]:
    path = f"releases/tags/{urllib.parse.quote(tag)}" if tag else "releases/latest"
    url = f"{API}/repos/{repo}/{path}"
    try:
        with OPENER.open(request(url, token, "application/vnd.github+json"), timeout=30) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        if error.code == 404:
            raise InstallerError(
                f"Kein Release für {repo}" + (f" mit dem Tag {tag}" if tag else "") + " gefunden.\n"
                "Starte zuerst den Workflow \"Build Ghostify\" (Reiter Actions -> Run workflow). Bei einem "
                "privaten Repository gib --token an oder setze GITHUB_TOKEN."
            ) from error
        if error.code in (401, 403):
            raise InstallerError(
                f"GitHub hat die Anfrage abgelehnt (HTTP {error.code}). Bei einem privaten Repository gib --token "
                "mit einem Token an, das es lesen darf; sonst warte ein paar Minuten (Anfragelimit) und versuche es erneut."
            ) from error
        raise InstallerError(f"GitHub hat mit HTTP {error.code} geantwortet.") from error
    except urllib.error.URLError as error:
        raise InstallerError(f"GitHub ist nicht erreichbar: {error.reason}") from error


def pick(assets: Sequence[Dict[str, Any]], patterns: Sequence[str]) -> Optional[Dict[str, Any]]:
    """The first asset matching the first pattern that matches anything."""
    for pattern in patterns:
        regex = re.compile(pattern, re.IGNORECASE)
        for asset in assets:
            if regex.search(asset["name"]):
                return asset
    return None


def choose_installer(assets: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    arm = "aarch64" in MACHINE or "arm64" in MACHINE
    if SYSTEM == "Windows":
        chosen = pick(assets, [r"-setup\.exe$", r"\.msi$"])
    elif SYSTEM == "Darwin":
        chosen = pick(assets, [r"(aarch64|arm64).*\.dmg$" if arm else r"(x64|x86_64).*\.dmg$", r"\.dmg$"])
    else:
        chosen = pick(assets, [r"\.AppImage$", r"\.deb$"])
    if chosen is None:
        names = ", ".join(a["name"] for a in assets) or "keine"
        raise InstallerError(f"Dieses Release enthält keinen Installer für {SYSTEM} (Dateien: {names}).")
    return chosen


def choose_cli(assets: Sequence[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    key = {"Windows": "windows", "Darwin": "macos"}.get(SYSTEM, "linux")
    return pick(assets, [rf"^ghostify-{key}-", r"^ghostify(\.exe)?$"])


def download(asset: Dict[str, Any], target_dir: Path, token: Optional[str]) -> Path:
    """Lädt eine Release-Datei herunter und prüft Größe und, falls bekannt, SHA-256."""
    name = Path(asset["name"]).name  # never trust a path from the server
    target = target_dir / name
    partial = target.with_name(name + ".part")
    # With a token the API URL is needed (private repositories); without one the public URL works.
    url = asset["url"] if token else asset["browser_download_url"]
    accept = "application/octet-stream"
    digest = hashlib.sha256()
    size = int(asset.get("size", 0))
    done = 0
    print(f"Lade {name} herunter ({size / 1048576:.1f} MB)")
    try:
        with OPENER.open(request(url, token, accept), timeout=60) as response, open(partial, "wb") as out:
            while True:
                chunk = response.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                done += len(chunk)
                if size:
                    print(f"\r  {done * 100 // size:3d} %", end="", flush=True)
        print()
    except (urllib.error.URLError, OSError) as error:
        partial.unlink(missing_ok=True)
        raise InstallerError(f"Download von {name} fehlgeschlagen: {error}") from error
    if size and done != size:
        partial.unlink(missing_ok=True)
        raise InstallerError(f"{name} ist unvollständig ({done} von {size} Bytes). Versuche es erneut.")
    expected = str(asset.get("digest") or "")
    if expected.startswith("sha256:") and expected[7:].lower() != digest.hexdigest():
        partial.unlink(missing_ok=True)
        raise InstallerError(f"{name} stimmt nicht mit der SHA-256-Prüfsumme überein. Es wurde nichts installiert.")
    partial.replace(target)
    return target


MAX_ZIP_FILES = 5000
MAX_ZIP_BYTES = 4 << 30  # 4 GB entpackt


def extract_zip(archive: Path, target: Path) -> List[Path]:
    """Entpackt eine ZIP-Datei sicher: nichts darf außerhalb des Zielordners landen."""
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    root = target.resolve()
    files: List[Path] = []
    try:
        with zipfile.ZipFile(archive) as bundle:
            infos = bundle.infolist()
            if len(infos) > MAX_ZIP_FILES or sum(i.file_size for i in infos) > MAX_ZIP_BYTES:
                raise InstallerError("Die ZIP-Datei ist ungewöhnlich groß und wird nicht entpackt.")
            for info in infos:
                destination = (root / info.filename).resolve()
                if destination != root and root not in destination.parents:
                    raise InstallerError(f"Unsicherer Pfad in der ZIP-Datei: {info.filename}")
                if info.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue
                if (info.external_attr >> 16) & 0o170000 == 0o120000:
                    continue  # Symlinks werden nicht angelegt
                destination.parent.mkdir(parents=True, exist_ok=True)
                with bundle.open(info) as source, open(destination, "wb") as out:
                    shutil.copyfileobj(source, out)
                files.append(destination)
    except zipfile.BadZipFile as error:
        raise InstallerError(f"{archive.name} ist keine gültige ZIP-Datei.") from error
    return files


def listing(files: Sequence[Path]) -> List[Dict[str, Any]]:
    return [{"name": f.name, "path": f} for f in files]


def installer_from_zip(archive: Path, work_dir: Path, want_cli: bool) -> Path:
    """Entpackt die ZIP-Datei, sucht den passenden Installer darin und liefert seinen Pfad."""
    say(f"Entpacke {archive.name}")
    files = extract_zip(archive, work_dir / ("entpackt-" + archive.stem))
    entries = listing(files)
    names = {f.name for f in files}
    if "Cargo.toml" in names and "installer.py" in names:
        raise InstallerError(
            "Das ist der Quellcode von Ghostify, kein fertiges Programm. Baue ihn zuerst über GitHub "
            "(Workflow \"Build Ghostify\") und lade danach die fertige Version."
        )
    try:
        chosen = choose_installer(entries)
    except InstallerError:
        shown = ", ".join(sorted(names)[:12]) or "leer"
        raise InstallerError(f"In der ZIP-Datei liegt kein Installer für {SYSTEM} (Dateien: {shown}).") from None
    if want_cli:
        cli_asset = choose_cli([e for e in entries if e["path"] != chosen["path"]])
        if cli_asset is not None:
            cli = work_dir / cli_asset["name"]
            shutil.copyfile(cli_asset["path"], cli)
            if SYSTEM != "Windows":
                cli.chmod(cli.stat().st_mode | stat.S_IXUSR)
            print(f"Kommandozeilen-Tool: {cli}")
        else:
            print("In der ZIP-Datei liegt kein Kommandozeilen-Tool, es wird übersprungen.")
    return chosen["path"]


def install(path: Path, silent: bool) -> None:
    if SYSTEM == "Windows":
        if path.suffix.lower() == ".msi":
            command = ["msiexec", "/i", str(path)] + (["/qn"] if silent else ["/passive"])
        else:
            command = [str(path)] + (["/S"] if silent else [])
        say("Starte den Installer" + (" (ohne Fenster)" if silent else ", folge dem Setup-Fenster"))
        result = subprocess.run(command, check=False)
        if result.returncode != 0:
            raise InstallerError(f"Der Installer wurde mit Code {result.returncode} beendet.")
        print("Installiert. Starte Ghostify über das Startmenü und klicke im Dashboard auf Patch (Spotify vorher schließen).")
    elif SYSTEM == "Darwin":
        print(f"Öffne {path} und ziehe Ghostify in den Ordner Programme.")
    elif path.suffix == ".AppImage":
        path.chmod(path.stat().st_mode | stat.S_IXUSR)
        print(f"Starten mit: {path}")
    else:
        print(f"Installieren mit: sudo apt install {path}")


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Lädt ein Ghostify-Release von GitHub herunter und installiert es.")
    parser.add_argument("--repo", default=DEFAULT_REPO, help=f"GitHub-Repository, Standard: {DEFAULT_REPO}")
    parser.add_argument("--tag", help="Release-Tag; ohne Angabe das neueste Release")
    parser.add_argument("--token", default=os.environ.get("GITHUB_TOKEN"), help="GitHub-Token für private Repositories")
    parser.add_argument("--dir", type=Path, default=Path.home() / "Downloads" / "ghostify", help="Download-Ordner")
    parser.add_argument("--silent", action="store_true", help="Windows: ohne Setup-Fenster installieren")
    parser.add_argument("--cli", action="store_true", help="zusätzlich das Kommandozeilen-Tool laden")
    parser.add_argument("--zip", type=Path, help="schon geladene ZIP-Datei (oder .exe/.msi) installieren, ohne Internet")
    parser.add_argument("--no-install", action="store_true", help="nur herunterladen")
    return parser.parse_args(list(argv))


def main(argv: Sequence[str]) -> int:
    args = parse_args(argv)
    try:
        if args.zip is not None:
            source = args.zip.expanduser()
            if not source.is_file():
                raise InstallerError(f"Die Datei {source} gibt es nicht.")
            args.dir.mkdir(parents=True, exist_ok=True)
            if source.suffix.lower() == ".zip":
                installer = installer_from_zip(source, args.dir, args.cli)
            elif source.suffix.lower() in (".exe", ".msi", ".dmg", ".deb", ".appimage"):
                installer = source
            else:
                raise InstallerError("--zip erwartet eine .zip-Datei oder einen Installer (.exe, .msi, .dmg, .deb, .AppImage).")
            if args.no_install:
                print(f"Installer: {installer}")
                return 0
            say("Installiere")
            install(installer, args.silent)
            return 0
        if not args.repo:
            if not sys.stdin.isatty():
                raise InstallerError("--repo NAME/REPO ist erforderlich.")
            args.repo = input("GitHub-Repository (zum Beispiel name/ghostify): ").strip()
            if args.repo.startswith("https://github.com/"):
                args.repo = args.repo[len("https://github.com/"):].strip("/")
        if not REPO_PATTERN.match(args.repo) or any(set(part) == {"."} for part in args.repo.split("/")):
            raise InstallerError("--repo muss so aussehen: NAME/REPO, zum Beispiel name/ghostify.")
        say(f"Suche das Release von {args.repo}")
        release = fetch_release(args.repo, args.tag, args.token)
        assets: List[Dict[str, Any]] = release.get("assets", [])
        print(f"Release: {release.get('name') or release.get('tag_name')}")

        args.dir.mkdir(parents=True, exist_ok=True)
        try:
            installer = download(choose_installer(assets), args.dir, args.token)
        except InstallerError:
            zip_asset = pick(assets, [r"windows.*\.zip$" if SYSTEM == "Windows" else r"(macos|darwin).*\.zip$" if SYSTEM == "Darwin" else r"linux.*\.zip$", r"\.zip$"])
            if zip_asset is None:
                raise
            print("Kein Installer im Release, aber eine ZIP-Datei: " + zip_asset["name"])
            archive = download(zip_asset, args.dir, args.token)
            installer = installer_from_zip(archive, args.dir, args.cli)
            args.cli = False  # schon erledigt
        if args.cli:
            cli_asset = choose_cli(assets)
            if cli_asset is None:
                print("Dieses Release enthält kein Kommandozeilen-Tool für dein System, es wird übersprungen.")
            else:
                cli = download(cli_asset, args.dir, args.token)
                if SYSTEM != "Windows":
                    cli.chmod(cli.stat().st_mode | stat.S_IXUSR)
                print(f"Kommandozeilen-Tool: {cli}")

        if args.no_install:
            print(f"Heruntergeladen nach {installer}")
            return 0
        say("Installiere")
        install(installer, args.silent)
        return 0
    except InstallerError as error:
        print(f"\nFehler: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nAbgebrochen.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
